package br.com.bernardo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroDeProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
